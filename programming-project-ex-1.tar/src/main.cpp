#include "Application.h"

int main() {

    Application app;

    return app.run();
}