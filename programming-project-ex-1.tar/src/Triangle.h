#ifndef TRIANGLE_H
#define TRIANGLE_H
#include "Drawable.h"

class Triangle : public Drawable{
    float x;
    float y;
    float base;
    float height;
    float r;
    float g;
    float b;

public:
    Triangle();
    Triangle(float x, float y, float base, float height, float r, float g, float b);

    void draw() const override;

    friend struct AppTest;
};

#endif