#include "Canvas.h"
#include "Circle.h"
#include "Triangle.h"
#include "Rectangle.h"
#include "Polygon.h"
#include "Scribble.h"

Canvas::Canvas(int x, int y, int w, int h) : bobcat::Canvas_(x, y, w, h), activeScribble(nullptr) {}

void Canvas::addScribble(Scribble* s) {
    drawables.push_back(s); 
}

void Canvas::addPoint(float x, float y, float r, float g, float b, int size) {
    Point* point = new Point(x, y, r, g, b, size);
    if (activeScribble != nullptr) {
        activeScribble->addPoint(point);
    } else {
    
        drawables.push_back(point);  
    }
}

void Canvas::setActiveScribble(Scribble* s) {
    activeScribble = s;
}

void Canvas::startScribble(float x, float y, float r, float g, float b, int size) {
    activeScribble = new Scribble();
    Point* point = new Point(x, y, r, g, b, size);
    activeScribble->addPoint(point);
    redraw();
}

void Canvas::continueScribble(float x, float y, float r, float g, float b, int size) {
    if (activeScribble != nullptr) {
        Point* point = new Point(x, y, r, g, b, size);
        activeScribble->addPoint(point);
        redraw();
    }
}

void Canvas::endScribble() {
    if (activeScribble != nullptr) {
        drawables.push_back(activeScribble);
        activeScribble = nullptr;
        redraw();
    }
}

void Canvas::addCircle(float x, float y, float radius, float r, float g, float b) {
    Circle* circle = new Circle(x, y, radius, r, g, b);
    drawables.push_back(circle); 
}

void Canvas::addTriangle(float x, float y, float base, float height, float r, float g, float b) {
    Triangle* triangle = new Triangle(x, y, base, height, r, g, b);
    drawables.push_back(triangle);  
}

void Canvas::addRectangle(float x, float y, float width, float height, float r, float g, float b) {
    Rectangle* rectangle = new Rectangle(x, y, width, height, r, g, b);
    drawables.push_back(rectangle);  
}

void Canvas::addPolygon(float x, float y, int sides, float sideLength, float r, float g, float b) {
    Polygon* polygon = new Polygon(x, y, sides, sideLength, r, g, b);
    drawables.push_back(polygon);  
}

void Canvas::clear() {
    for (auto drawable : drawables) {
        delete drawable;
    }
    drawables.clear();  
    redraw(); 
}

void Canvas::render() {
    for (auto drawable : drawables) {
        drawable->draw();  
    }
}
