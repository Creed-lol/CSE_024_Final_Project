#include "Scribble.h"
#include <GL/freeglut.h>
#include <cmath>


Scribble::Scribble() {

}

void Scribble::addPoint(Point* pt) {
    points.push_back(pt);
}

void Scribble::draw() const {
    for (Point* pt : points) {
        pt->draw();
    }
}

