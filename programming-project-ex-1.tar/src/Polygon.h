#ifndef POLYGON_H
#define POLYGON_H
#include "Drawable.h"

class Polygon : public Drawable{
    float x;
    float y;
    int sides;
    float length;
    float r;
    float g;
    float b;

public:
    Polygon();
    Polygon(float x, float y, int sides, float length, float r, float g, float b);

    void draw() const override;

    friend struct AppTest;
};

#endif